<?php
defined( 'ABSPATH' ) || die();
?>
<div class="wlsm-no-record-found">
	<span class="wlsm-no-record-found-text wlsm-font-bold wlsm-text-danger">
		<?php esc_html_e( 'There is no student or parent record.', 'school-management' ); ?>
	</span>
</div>
