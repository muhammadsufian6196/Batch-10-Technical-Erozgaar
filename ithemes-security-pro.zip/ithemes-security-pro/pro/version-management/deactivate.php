<?php

require_once( dirname( __FILE__ ) . '/class-itsec-version-management.php' );

ITSEC_Version_Management::deactivate();
