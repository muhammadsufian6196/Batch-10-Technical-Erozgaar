<?php

ITSEC_Core::get_scheduler()->unschedule( 'dashboard-consolidate-events' );
