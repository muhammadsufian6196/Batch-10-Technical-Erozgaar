<?php

require_once( dirname( __FILE__ ) . '/class-itsec-geolocation.php' );
$geolocation = new ITSEC_Geolocation();
$geolocation->run();