<?php

require_once( 'class-itsec-user-logging.php' );
$itsec_user_logging = new ITSEC_User_Logging();
$itsec_user_logging->run();
