import keyMirror from 'keymirror';

export default keyMirror({
  SORTABLE_LIST_LINK_SETTINGS_CLOSE: null,
  SORTABLE_LIST_LINK_SETTINGS_SAVE: null,
});
